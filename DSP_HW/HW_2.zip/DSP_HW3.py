import scipy.io as sp
from scipy import signal
from scipy.io import wavfile
from scipy.io.wavfile import write
import matplotlib.pyplot as plot
import numpy as np
seis = sp.loadmat('./Erebus_seismogram.mat')

